// Page Not Found Generic Page

const Page404 = () => {

    return (
        <h1 style={{ marginLeft: 'auto', marginRight: 'auto', width: '50%' }}>Page Not Found</h1>
    )
}

export default Page404;