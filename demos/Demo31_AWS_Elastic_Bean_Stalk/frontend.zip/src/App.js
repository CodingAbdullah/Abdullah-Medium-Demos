import './App.css';

const App = () => {
  return (
    <div className="App">
      <h1>This is the Home Page!!</h1>
    </div>
  );
}

export default App;